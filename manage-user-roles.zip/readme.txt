=== Manage User Roles ===
Contributors: airtonvancin
Donate link: https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=93975544-d3277b00-b729-47a7-bfa0-9a19d4e5afec
Tags: user, roles, administration, adm
Requires at least: 3.0
Tested up to: 6.9
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show only your posts publications

Restricts users to only see their own posts in the WordPress admin.

== Installation ==

* Upload plugin files to your plugins folder, or install using WordPress built-in Add New Plugin installer;
* Activate the plugin;
* Navigate to Plugin Settings and fill settings.

== Frequently Asked Questions ==

= What is the plugin license? =

* This plugin is released under a GPL license.

== Screenshots ==

== Changelog ==

= 1.1.0 =
* Remove unused files and code.
* Update plugin version.

= 1.0.0 =

* Initial version.

== Upgrade Notice ==

= 1.1.0 =
* Remove unused files and code.
* Update plugin version.

= 1.0.0 =

* Initial version.

== License ==

This file is part of Manage User Roles.

Manage User Roles is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published
by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

Manage User Roles is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

Get a copy of the GNU General Public License in <http://www.gnu.org/licenses/>.
